7z e .\SF-Pro.dmg
7z e SF &#39;.\SF Pro Fonts.pkg&#39;
7z e Payload~
install *.ttf *.otf